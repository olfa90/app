menufortouristApp.factory('UserFactory', function() {
  return {
      name : 'anonymous',
      locale : 'EN',
      lat: '',
      lng: ''
  };
});