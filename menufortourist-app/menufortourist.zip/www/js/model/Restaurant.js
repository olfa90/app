function Restaurant() {
	"use strict";

 	var id = null;
  	var created_at = null;
	var updated_at = null;
	var distance = null;
	
	var name = null;
	var description = null;

	var specialty = null;

	var locale = null;

	var address = new Address();

	var phone = null;
	var openHours = null;
	var homepage = null;

	var photoUrl = null;

	var menuUrl = null;

	var secoes = [];

}