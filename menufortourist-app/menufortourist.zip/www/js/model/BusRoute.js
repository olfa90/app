function BusRoute() {
	"use strict";

	var id = null;
	var longName = null;
	var agencyId = null;
	var lastModifiedDate = null;
 	var shortName = null;

 	var stops = [];
 	
 	var weektable = [];
 	var saturdaytable = [];
 	var sundaytable = [];

}