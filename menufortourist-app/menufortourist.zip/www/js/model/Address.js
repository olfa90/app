function Address() {
	"use strict";
	
	var lat = null;
    var lng = null;
    var street = null;
    var number = null;
    var complement = null;
    var neighbourhood = null;
    var city = null;
    var state = null;
    var country = null;
}