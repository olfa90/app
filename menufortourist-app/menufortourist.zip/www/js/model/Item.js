function Item() {
	"use strict";

 	var id = null;
  	var created_at = null;
	var updated_at = null;
	
	var titulo = null;
	var descricao = null;

}