function Filter() {
	"use strict";

 	var specialties = [];
	var specialty = null;
	var selectedSpecialties = [];

	var cities = [];
	var selectedCity = null;
	var selectedNeighbourhoods = [];

	var around = true;
	var lat = null;
	var lng = null;
	var distance = null;

	var openHours = null;
	
	var image = false;
}