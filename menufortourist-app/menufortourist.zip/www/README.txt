HOW TO RUN - TESTING

From terminal (inside menu4tourist folder), run:
> python -m SimpleHTTPServer

Or, From terminal (inside menu4tourist/app folder), run:
> node servidor.js